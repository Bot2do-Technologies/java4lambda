const sql = require("mssql");
const { config } = require("./config");

const connectToDatabase = async () => {
  try {
    await sql.connect(config);
    console.log("Connected to the database");
  } catch (err) {
    console.error("Error connecting to MSSQL:", err);
  }
};

const executeQuery = async (query) => {
  try {
    const result = await sql.query(query);
    return result.recordset;
  } catch (err) {
    console.error("Error executing query:", err);
    throw err;
  }
};

module.exports = {
  connectToDatabase,
  executeQuery,
};
