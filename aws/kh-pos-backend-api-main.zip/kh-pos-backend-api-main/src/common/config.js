exports.config = {
  user: "khtestserver_",
  password: "khtestserver",
  server: "sql.bsite.net/MSSQL2016SQL",
  database: "khtestserver_",
  options: {
    encrypt: true, // Use this if you're on Windows Azure
  },
};
