const db = require("../common/db");

module.exports = {
  getAllUsers: async (req, res) => {
    try {
      const query = "SELECT * FROM user";
      const data = await db.executeQuery(query);

      res.status(200).json(data);
    } catch (err) {
      console.error(err);
      res.status(500).json({ success: false, error: err.message });
    }
  },
  createUser: async (req, res) => {
    try {
      const { username, email, password } = req.body;

      // Validate inputs (add more validation as needed)
      if (!username || !email || !password) {
        return res
          .status(400)
          .json({ success: false, error: "Missing required fields" });
      }

      const query = `INSERT INTO user (username, email, password) VALUES ('${username}', '${email}', '${password}')`;
      const result = await db.executeQuery(query);

      res
        .status(201)
        .json({
          success: true,
          message: "User created successfully",
          data: result,
        });
    } catch (err) {
      console.error(err);
      res.status(500).json({ success: false, error: err.message });
    }
  },
};
