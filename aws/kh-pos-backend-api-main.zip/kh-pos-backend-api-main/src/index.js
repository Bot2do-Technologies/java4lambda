const express = require("express");
const app = express();
const { response } = require("./common/utils");
const db = require("./common/db");

// Routes setup
app.use(require("./routes"));

// Catch 404 and forward to error handler
app.use((req, res, next) => {
  return res.status(404).json(response(false, {}, "API not found"));
});

db.connectToDatabase();

// Error handler
app.use((err, req, res, next) => {
  console.log(err);
  return res.status(500).json(response(false, {}, err.message));
});

const PORT = process.env.PORT || 3000;

// Start the server
app.listen(PORT, () => {
  console.log(`Server is running on port ${PORT}`);
});

module.exports = app;
