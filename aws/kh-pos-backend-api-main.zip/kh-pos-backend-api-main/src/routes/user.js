const UserController = require("../controllers/user");
const express = require("express");
const router = express.Router();

/**
 * @api {get} /get getUsers
 * @apiVersion 1.0.0
 * @apiName getAllUsers
 * @apiGroup User
 *
 */
router.get("/getUsers", (req, res) => UserController.getAllUsers(req, res));

module.exports = router;
