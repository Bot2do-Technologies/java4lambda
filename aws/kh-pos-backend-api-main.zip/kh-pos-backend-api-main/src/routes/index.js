const express = require("express");
const router = express.Router();
let user = require("./user");

router.use("/api", user);

module.exports = router;
